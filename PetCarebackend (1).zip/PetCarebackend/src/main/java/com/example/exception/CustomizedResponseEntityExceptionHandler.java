package com.example.exception;

public class CustomizedResponseEntityExceptionHandler {

}
